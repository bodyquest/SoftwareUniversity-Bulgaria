﻿namespace TeisterMask.DataProcessor
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    using Data;
    using Newtonsoft.Json;
    using System.Text;
    using TeisterMask.Data.Models;
    using TeisterMask.DataProcessor.ImportDto;
    using System.Linq;
    using System.Xml.Serialization;
    using System.IO;
    using TeisterMask.Data.Models.Enums;
    using System.Globalization;

    public class Deserializer
    {
        private const string ErrorMessage = "Invalid data!";

        private const string SuccessfullyImportedProject
            = "Successfully imported project - {0} with {1} tasks.";

        private const string SuccessfullyImportedEmployee
            = "Successfully imported employee - {0} with {1} tasks.";

        public static string ImportProjects(TeisterMaskContext context, string xmlString)
        {
            //throw new NotImplementedException();

            //1. Call the serializer
            XmlSerializer serializer = new XmlSerializer(
                typeof(ImportProjectDto[]),
                new XmlRootAttribute("Projects"));

            //2. Deserialize
            var projectDtos = (ImportProjectDto[])serializer.Deserialize(new StringReader(xmlString));

            var sb = new StringBuilder();
            var validProjects = new List<Project>();
            var validTasks = new List<TaskDto>();

            //3. Go through each DTO object
            foreach (var dto in projectDtos)
            {
                //4. Validate each purchaseDTO
                if (!IsValid(dto))
                {
                    sb.AppendLine(ErrorMessage);
                    continue;
                }

                // TASKS VALIDATION
                //bool validTask = dto.Tasks.All(IsValid);
                foreach (var task in dto.Tasks)
                {
                    if (IsValid(task) && !String.IsNullOrEmpty(task.OpenDate) && !String.IsNullOrEmpty(task.DueDate) && !String.IsNullOrEmpty(dto.DueDate))
                    {
                        var date1 = DateTime.ParseExact(task.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        var date2 = DateTime.ParseExact(dto.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        var date3 = DateTime.ParseExact(task.DueDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                        var date4 = DateTime.ParseExact(dto.DueDate, "dd/MM/yyyy", CultureInfo.InvariantCulture);

                        //if (!isValidEnumType)
                        //{
                        //    sb.AppendLine(ErrorMessage);
                        //    continue;
                        //}
                        //if (!isValidEnumLabel)
                        //{
                        //    sb.AppendLine(ErrorMessage);
                        //    continue;
                        //}

                        int resultOD = DateTime.Compare(date1, date2);
                        int resultDD = DateTime.Compare(date3, date4);

                        if (resultOD < 0 ||
                            resultDD > 0
                            )
                        {
                            //relationship = "is earlier than";
                            sb.AppendLine(ErrorMessage);
                        }
                        //else if (resultDD > 0 || )
                        //{
                        //    //relationship = "is later than";
                        //}

                        else if (resultOD > 0 && resultDD < 0 && IsValid(task))
                        {
                            //relationship = "is earlier than";
                            validTasks.Add(task);
                        }
                    }
                    else
                    {
                        sb.AppendLine(ErrorMessage);
                    }

                }

                //9. Create the Project object

                ////5. Validate enums


                var project = new Project
                {
                    Name = dto.Name,
                    OpenDate = DateTime.ParseExact(dto.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    DueDate = DateTime.ParseExact(dto.DueDate, "dd/MM/yyyy", CultureInfo.InvariantCulture),
                };

                foreach (var item in validTasks)
                {
                    var validType = (ExecutionType)Enum.Parse(typeof(ExecutionType), item.ExecutionType);
                    var validLabel = (LabelType)Enum.Parse(typeof(LabelType), item.LabelType);

                    var task = new Task
                    {
                        Name = item.Name,
                        OpenDate = DateTime.ParseExact(item.OpenDate, "dd/MM/yyyy", CultureInfo.InvariantCulture),
                        DueDate = DateTime.ParseExact(item.DueDate, "dd/MM/yyyy", CultureInfo.InvariantCulture),
                        ExecutionType = validType,
                        LabelType = validLabel
                    };

                    project.Tasks.Add(task);
                }

                //10. Add to the collection
                validProjects.Add(project);
                sb.AppendLine(string.Format(SuccessfullyImportedProject, project.Name, project.Tasks.Count));
            }

            //11. Add the collection of Projects in the Database
            context.Projects.AddRange(validProjects);
            context.SaveChanges();

            string result = sb.ToString().TrimEnd();

            return result;
        }

        public static string ImportEmployees(TeisterMaskContext context, string jsonString)
        {
            throw new NotImplementedException();

            ////1. Deserialize to DTO
            //var employeeDtos = JsonConvert.DeserializeObject<ImportEmployeeDto[]>(jsonString);

            //var sb = new StringBuilder();
            //var validEmployees = new List<Employee>();

            ////2. Validation check
            //foreach (var dto in employeeDtos)
            //{
            //    if (IsValid(dto))
            //    {
            //        var employee = new Employee
            //        {
            //            Username = dto.Username,
            //            Email = dto.Email,
            //            Phone = dto.Phone,

            //        };

            //        //foreach (var task in dto.Tasks)
            //        //{
            //        //    EmployeesTasks = dto.Tasks.Select(m => new Task
            //        //    {
            //        //        Description = m.Description,
            //        //        Sender = m.Sender,
            //        //        Address = m.Address
            //        //    })
            //        //  .ToArray()
            //        //}

            //        validEmployees.Add(employee);
            //        sb.AppendLine(string.Format(SuccessfullyImportedEmployee, dto.Username, dto.Tasks.Count())); // TODO Check if CORRECT
            //    }
            //    else
            //    {
            //        sb.AppendLine(ErrorMessage);
            //    }
            //}

            //// Add To DB
            //context.Employees.AddRange(validEmployees);
            //context.SaveChanges();

            //return sb.ToString().TrimEnd();
        }

        private static bool IsValid(object dto)
        {
            var validationContext = new ValidationContext(dto);
            var validationResult = new List<ValidationResult>();

            return Validator.TryValidateObject(dto, validationContext, validationResult, true);
        }
    }
}