function attachEvents() {
    const baseUrl = "https://api.backendless.com/C37FA95F-0D6A-9940-FF9B-AAABADC18D00/438AA7CE-7E50-4CA0-B6E7-6EEE19783B2E/data/players";
    
    const elements = {
        players: document.querySelector("#players"),
        canvas: document.querySelector("#canvas"),
        addPlayerBtn: document.querySelector("#addPlayer"),
        reloadBtn: document.querySelector("#reload"),
        saveBtn: document.querySelector("#save"),

        nameInput: document.querySelector("#addName")
    }

    elements.addPlayerBtn.addEventListener("click", addPlayer);

    loadPlayers();

    function loadPlayers(){
        fetch(baseUrl)
        .then(response => response.json())
        .then(data =>

            data.forEach(player => {

                const playBtn = createHTML("button", "Play");
                playBtn.addEventListener("click", function () {
                    elements.saveBtn.style.display = "inline-block";  
                    elements.saveBtn.addEventListener("click", function(){
                        updatePlayer(player);
                    }, false);

                    elements.reloadBtn.style.display = "inline-block";
                    elements.reloadBtn.addEventListener("click", function(){
                        reloadPlayer(player);
                    });

                    elements.canvas.style.display = "block";

                    loadCanvas(player);
                });

                const deleteBtn = createHTML("button", "Delete");
                deleteBtn.addEventListener("click", function () {
                    try{
                        deleteBtn.disabled = true;
                        deleteBtn.textContent = "Please wait...";
                        fetch((`${baseUrl}/${player.objectId}`), {
                            method: 'DELETE',
                            headers: {
                                'Content-Type': 'application/json'
                            }
                        })
                        .then(response => response.json());
                        playerDiv.remove();
                    }
                    catch(error){
                        console.error(error);
                        alert(error);

                        deleteBtn.disabled = false;
                        deleteBtn.textContent = "Delete";
                    }
                });

                let playerDiv = createHTML("div", [
                    createHTML("div", `Name:${player.name}`),
                    createHTML("div", `Money:${player.money}`),
                    createHTML("div", `Bullets:${player.bullets}`),
                    createHTML("div", playBtn),
                    createHTML("div", deleteBtn),
                ], {className: "player"});

                elements.players.appendChild(playerDiv);
            })
        );
    }

    function addPlayer(){
        const name = elements.nameInput.value;
        
        if(name.length === 0){
            alert("Field can not be empty");
            return;
        }

        const data = { name, "money":500, "bullets":6 };

        try{
            fetch(baseUrl, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                  },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(result => {
                elements.nameInput.disabled = true;
                elements.addPlayerBtn.disabled = true;
                elements.players.textContent = "";
                elements.nameInput.value = "";

                loadPlayers();
            })
           
        }catch(error){
            alert(error);
        }finally{
            elements.nameInput.disabled = false;
            elements.addPlayerBtn.disabled = false;
        }     
    }

    function updatePlayer (player) {
        try{
            fetch(`${baseUrl}/${player.objectId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(player)
            })
            .then(res => res.json())
            .then(res => {
                elements.players.textContent = "";

                loadPlayers();

                elements.saveBtn.style.display = "none";               
                elements.reloadBtn.style.display = "none";
                elements.canvas.style.display = "none";

                clearInterval(elements.canvas.intervalId);
            })
           
        }catch(error){
            alert(error);
        }
    }

    function reloadPlayer(player){
        try{
            if(player.money < 60){
                alert("Not enough money to reload!");
                return;
            }
            player.money -= 60;
            player.bullets = 6;
            fetch(`${baseUrl}/${player.objectId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(player)
            })
            .then(response => response.json())
            .then(result => {
                elements.players.textContent = "";

                loadPlayers();
            })
           
        }catch(error){
            alert(error);
        }
    }

    function createHTML(type, content, attributes){
        const result = document.createElement(type);
    
        if (attributes !== undefined) {
            Object.assign(result, attributes);
        }
    
        if (Array.isArray(content)) {
            content.forEach(append);
        }else if(content !== null && content !== undefined){
            append(content);
        }
    
        function append(node) {
            if (typeof node === "string" || typeof node === "number") {
                node = document.createTextNode(node);
            }
    
            result.appendChild(node);
        }
    
        return result;
    }
}